# HOME PAGE FOR MY SITE
Welcome on your RIKIKI example page
## What we do here

It's work, so you can begin to customize your site.  

You can change your home page by editing "home.md". You can do more complex homepage by creating a "home.htm" file because HTML allow more control then markdown on page layout. 

If you change the name of "home.md" (you can use the name you want), **dont forget to apply the same name in index.txt**.

Use a good text editor with syntax highlight like [notepad++](https://notepad-plus-plus.org) or [atom](https://atom.io/)  

- There one file you should not touch : `main.js`
- You can modify `style.css` carefully 
- You need to edit `index.txt` to mirror the structure of your site

all others file are your's : thats for site content.



